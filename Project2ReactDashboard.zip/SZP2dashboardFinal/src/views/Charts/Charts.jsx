import React from "react";
import PropTypes from "prop-types";
import jyan1 from "./jyan1.png";
import jyan2 from "./jyan2.png";
import i1 from "./1.png";
import i2 from "./2.png";
import i3 from "./3.png";
import i4 from "./4.png";
// react plugin for creating charts
import ChartistGraph from "react-chartist";
// @material-ui/core
import withStyles from "@material-ui/core/styles/withStyles";
import Icon from "@material-ui/core/Icon";
// @material-ui/icons
import Store from "@material-ui/icons/Store";
import Warning from "@material-ui/icons/Warning";
import DateRange from "@material-ui/icons/DateRange";
import LocalOffer from "@material-ui/icons/LocalOffer";
import Update from "@material-ui/icons/Update";
import ArrowUpward from "@material-ui/icons/ArrowUpward";
import AccessTime from "@material-ui/icons/AccessTime";
import Accessibility from "@material-ui/icons/Accessibility";
import BugReport from "@material-ui/icons/BugReport";
import Code from "@material-ui/icons/Code";
import Cloud from "@material-ui/icons/Cloud";
// core components
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Table from "components/Table/Table.jsx";
import Tasks from "components/Tasks/Tasks.jsx";
import CustomTabs from "components/CustomTabs/CustomTabs.jsx";
import Danger from "components/Typography/Danger.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardFooter from "components/Card/CardFooter.jsx";

import { bugs, website, server } from "variables/general.jsx";

import {
  dailySalesChart,
  emailsSubscriptionChart,
  completedTasksChart
} from "variables/charts.jsx";

import dashboardStyle from "assets/jss/material-dashboard-react/views/dashboardStyle.jsx";

class Dashboard extends React.Component {
  state = {
    value: 0
  };
  handleChange = (event, value) => {
    this.setState({ value });
  };

  handleChangeIndex = index => {
    this.setState({ value: index });
  };
  render() {
    const { classes } = this.props;
    return (
      <div>
        <GridContainer>
          <GridItem xs={12} sm={12} md={12}>
            <Card chart>
                <CardHeader color="info">
                  <img src={jyan1} alt="jyan1" height="410" width="920"></img>
                </CardHeader>
                <CardBody>
                  <h4 className={classes.cardTitle}>Area Surveyed: Bay Area</h4>
                  <p className={classes.cardCategory}>
                    Never would have suspected this distribution...
                  </p>
                </CardBody>
                <CardFooter chart>
                  <div className={classes.stats}>
                    <AccessTime /> Data Recorded 3 March 2019
                  </div>
                </CardFooter>
              </Card>
          </GridItem>
          <GridItem xs={12} sm={12} md={12}>
            <Card chart>
                <CardHeader color="info">
                  <img src={jyan2} alt="jyan2" height="410" width="920"></img>
                </CardHeader>
                <CardBody>
                  <h4 className={classes.cardTitle}>Area Surveyed: SF</h4>
                  <p className={classes.cardCategory}>
                    San Francisco is the powerhouse of the tech world
                  </p>
                </CardBody>
                <CardFooter chart>
                  <div className={classes.stats}>
                    <AccessTime /> Data Recorded 3 March 2019
                  </div>
                </CardFooter>
              </Card>
          </GridItem>
          <GridItem xs={12} sm={8} md={8}>
            <Card chart>
                <CardHeader color="info">
                  <img src={i1} alt="i1" height="410" width="580"></img>
                </CardHeader>
                <CardBody>
                  <h4 className={classes.cardTitle}>GeoJSON to JSON</h4>
                  <p className={classes.cardCategory}>
                  </p>
                </CardBody>
                <CardFooter chart>
                  <div className={classes.stats}>
                    <AccessTime /> Data Recorded 3 March 2019
                  </div>
                </CardFooter>
              </Card>
          </GridItem>
          <GridItem xs={12} sm={8} md={8}>
            <Card chart>
                <CardHeader color="info">
                  <img src={i2} alt="i2" height="410" width="580"></img>
                </CardHeader>
                <CardBody>
                  <h4 className={classes.cardTitle}>JSON file</h4>
                  <p className={classes.cardCategory}>
                  </p>
                </CardBody>
                <CardFooter chart>
                  <div className={classes.stats}>
                    <AccessTime /> Data Recorded 3 March 2019
                  </div>
                </CardFooter>
              </Card>
          </GridItem>
          <GridItem xs={12} sm={8} md={8}>
            <Card chart>
                <CardHeader color="info">
                  <img src={i3} alt="i3" height="410" width="580"></img>
                </CardHeader>
                <CardBody>
                  <h4 className={classes.cardTitle}>JSON to .JS</h4>
                  <p className={classes.cardCategory}>
                  </p>
                </CardBody>
                <CardFooter chart>
                  <div className={classes.stats}>
                    <AccessTime /> Data Recorded 3 March 2019
                  </div>
                </CardFooter>
              </Card>
          </GridItem>
          <GridItem xs={12} sm={8} md={8}>
            <Card chart>
                <CardHeader color="info">
                  <img src={i4} alt="i4" height="410" width="580"></img>
                </CardHeader>
                <CardBody>
                  <h4 className={classes.cardTitle}>Google Maps API</h4>
                  <p className={classes.cardCategory}>
                  </p>
                </CardBody>
                <CardFooter chart>
                  <div className={classes.stats}>
                    <AccessTime /> Data Recorded 3 March 2019
                  </div>
                </CardFooter>
              </Card>
          </GridItem>
        </GridContainer>

      </div>
    );
  }
}

Dashboard.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(dashboardStyle)(Dashboard);
