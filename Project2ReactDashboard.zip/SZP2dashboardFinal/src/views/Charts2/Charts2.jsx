import React from "react";
import PropTypes from "prop-types";
import pban1 from "./pban1.png";
import pban2 from "./pban2.png";
import pbc1 from "./pbc1.png";
import pbc2 from "./pbc2.png";
import pbc3 from "./pbc3.png";
import pblegend1 from "./pblegend1.png";
// react plugin for creating charts
import ChartistGraph from "react-chartist";
// @material-ui/core
import withStyles from "@material-ui/core/styles/withStyles";
import Icon from "@material-ui/core/Icon";
// @material-ui/icons
import Store from "@material-ui/icons/Store";
import Warning from "@material-ui/icons/Warning";
import DateRange from "@material-ui/icons/DateRange";
import LocalOffer from "@material-ui/icons/LocalOffer";
import Update from "@material-ui/icons/Update";
import ArrowUpward from "@material-ui/icons/ArrowUpward";
import AccessTime from "@material-ui/icons/AccessTime";
import Accessibility from "@material-ui/icons/Accessibility";
import BugReport from "@material-ui/icons/BugReport";
import Code from "@material-ui/icons/Code";
import Cloud from "@material-ui/icons/Cloud";
// core components
import GridItem from "components/Grid/GridItem.jsx";
import GridContainer from "components/Grid/GridContainer.jsx";
import Table from "components/Table/Table.jsx";
import Tasks from "components/Tasks/Tasks.jsx";
import CustomTabs from "components/CustomTabs/CustomTabs.jsx";
import Danger from "components/Typography/Danger.jsx";
import Card from "components/Card/Card.jsx";
import CardHeader from "components/Card/CardHeader.jsx";
import CardIcon from "components/Card/CardIcon.jsx";
import CardBody from "components/Card/CardBody.jsx";
import CardFooter from "components/Card/CardFooter.jsx";

import { bugs, website, server } from "variables/general.jsx";

import {
  dailySalesChart,
  emailsSubscriptionChart,
  completedTasksChart
} from "variables/charts.jsx";

import dashboardStyle from "assets/jss/material-dashboard-react/views/dashboardStyle.jsx";

class Dashboard extends React.Component {
  state = {
    value: 0
  };
  handleChange = (event, value) => {
    this.setState({ value });
  };

  handleChangeIndex = index => {
    this.setState({ value: index });
  };
  render() {
    const { classes } = this.props;
    return (
      <div>
        <GridContainer>
          <GridItem xs={12} sm={8} md={8}>
          <Card chart>
                <CardHeader color="info">
                  <img src={pban1} alt="pban1" height="410" width="580"></img>
                </CardHeader>
                <CardBody>
                <img src={pblegend1} alt="pblegend1" height="130" width="180"></img>
                </CardBody>
                <CardFooter chart>
                  <div className={classes.stats}>
                    <AccessTime /> Data Recorded 3 March 2019
                  </div>
                </CardFooter>
              </Card>
          </GridItem>
          <GridItem xs={12} sm={8} md={8}>
          <Card chart>
                <CardHeader color="info">
                  <img src={pban2} alt="pban2" height="410" width="580"></img>
                </CardHeader>
                <CardBody>
                  <h4 className={classes.cardTitle}></h4>
                  <p className={classes.cardCategory}>
                  </p>
                </CardBody>
                <CardFooter chart>
                  <div className={classes.stats}>
                    <AccessTime /> Data Recorded 3 March 2019
                  </div>
                </CardFooter>
              </Card>
          </GridItem>
          <GridItem xs={12} sm={8} md={8}>
          <Card chart>
                <CardHeader color="info">
                  <img src={pbc1} alt="pbc1" height="410" width="580"></img>
                </CardHeader>
                <CardBody>
                  <h4 className={classes.cardTitle}></h4>
                  <p className={classes.cardCategory}>
                  </p>
                </CardBody>
                <CardFooter chart>
                  <div className={classes.stats}>
                  </div>
                </CardFooter>
              </Card>
          </GridItem>
          <GridItem xs={12} sm={8} md={8}>
          <Card chart>
                <CardHeader color="info">
                  <img src={pbc2} alt="pbc2" height="410" width="580"></img>
                </CardHeader>
                <CardBody>
                  <h4 className={classes.cardTitle}></h4>
                  <p className={classes.cardCategory}>
                  </p>
                </CardBody>
                <CardFooter chart>
                  <div className={classes.stats}>
                  </div>
                </CardFooter>
              </Card>
          </GridItem>
          <GridItem xs={12} sm={8} md={8}>
          <Card chart>
                <CardHeader color="info">
                  <img src={pbc3} alt="pbc3" height="410" width="580"></img>
                </CardHeader>
                <CardBody>
                  <h4 className={classes.cardTitle}></h4>
                  <p className={classes.cardCategory}>
                  </p>
                </CardBody>
                <CardFooter chart>
                  <div className={classes.stats}>
                  </div>
                </CardFooter>
              </Card>
          </GridItem>
        </GridContainer>
      </div>
    );
  }
}

Dashboard.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(dashboardStyle)(Dashboard);
