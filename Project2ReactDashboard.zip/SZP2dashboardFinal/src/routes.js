// @material-ui/icons
import Dashboard from "@material-ui/icons/Dashboard";
import Person from "@material-ui/icons/Person";
import LibraryBooks from "@material-ui/icons/LibraryBooks";
import BubbleChart from "@material-ui/icons/BubbleChart";
import LocationOn from "@material-ui/icons/LocationOn";
import Notifications from "@material-ui/icons/Notifications";
import Unarchive from "@material-ui/icons/Unarchive";
import Language from "@material-ui/icons/Language";
// core components/views for Admin layout
import Charts from "views/Charts/Charts.jsx";
import Charts2 from "views/Charts2/Charts2.jsx";
import UserProfile from "views/UserProfile/UserProfile.jsx";
import TableList from "views/TableList/TableList.jsx";
import RawData from "views/RawData/RawData.jsx";
import Icons from "views/Icons/Icons.jsx";
import Maps from "views/Maps/Maps.jsx";
import NotificationsPage from "views/Notifications/Notifications.jsx";
import UpgradeToPro from "views/UpgradeToPro/UpgradeToPro.jsx";
import WordCloud1 from "views/WordCloud1/WordCloud1.jsx";

// core components/views for RTL layout
import RTLPage from "views/RTLPage/RTLPage.jsx";

const dashboardRoutes = [
  {
    path: "/map",
    name: "Map",
    rtlName: "ملف تعريفي للمستخدم",
    icon: Language,
    component: Charts,
    layout: "/admin"
  },
  {
    path: "/word-cloud/1",
    name: "Word Cloud",
    rtlName: "قائمة الجدول",
    icon: BubbleChart,
    component: WordCloud1,
    layout: "/admin"
  },
  {
    path: "/charts/2",
    name: "Charts",
    rtlName: "لوحة القيادة",
    icon: Dashboard,
    component: Charts2,
    layout: "/admin"
  },  
  {
    path: "/raw-data",
    name: "Raw Data",
    rtlName: "طباعة",
    icon: "content_paste",
    component: RawData,
    layout: "/admin"
  }
];

export default dashboardRoutes;
