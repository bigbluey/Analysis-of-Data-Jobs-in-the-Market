import React, { Component } from 'react';

class HomePage extends Component {
  render() {
    return (
      <div>
        Home page
      </div>
    )
  }
}

export default HomePage;