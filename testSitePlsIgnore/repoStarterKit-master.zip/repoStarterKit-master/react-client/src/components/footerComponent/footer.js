import React, { Component } from 'react';

class Footer extends Component {
  render() {
    return (
      <footer>
        <div>
          Footer component
        </div>
      </footer>
    )
  }
}

export default Footer;